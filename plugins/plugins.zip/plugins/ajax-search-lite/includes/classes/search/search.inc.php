<?php
if (!defined('ABSPATH')) die('-1');

/* Search related classes */
require_once(ASL_CLASSES_PATH . "search/search.controller.class.php");
require_once(ASL_CLASSES_PATH . "search/search.class.php");
require_once(ASL_CLASSES_PATH . "search/search_content.class.php");