<?php
  /* Ajax functions here */

  /*	
  add_action('wp_ajax_functionname', 'functionname');
  function functionname() {
    print_r("something");
    die();
  } 
  */
  
?>